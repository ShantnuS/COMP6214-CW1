Name: Shantnu Singh
Email: ss18g15@soton.ac.uk
Student ID: 27763153

The website has a can be hosted on a local webserver. The homepage is 'index.html'. 
The website has also been hosted online on GitHub and is available at: https://www.shantnu.me/COMP6214-CW1/